var SinhVien = function (){
    this.MaSV = '';
    this.TenSV = '';
    this.Email = '';
    this.SoDT = '';
    this.DiemToan = '';
    this.DiemLy = '';
    this.DiemHoa = '';
}